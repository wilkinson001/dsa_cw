<?php
  include("phpFlickrGallery.php");
  
  $username = 'mikel_duke';    
  $amount_per_page = 12;

  if (isset($_GET['image']))
    $imageid = $_GET['image'];
  else $imageid = false;

  if (isset($_GET['set']))
    $setid = $_GET['set'];
  else $setid = false;
?>
  
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="phpFlickrGallery.css" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>phpFlickrGallery</title>
  </head>
  <body>
    <? 
      if (!$imageid) showGallery($username, $amount_per_page);
      else viewImage($imageid, "b");
    ?>
    <hr>
    Thumb test: <br>
    <?    viewThumb("6866186987"); ?><br>
    <div class="flickr_clear"></div>
    <hr>
    Set List Test: <br>
    <?    showUserSets($username); ?> <br>
    <div class="flickr_clear"></div>
    <hr>
    Set photo list: <br>
    <?    if ($setid) showPhotosInSet($setid); ?> <br>
    <br>
  </body>
</html>
