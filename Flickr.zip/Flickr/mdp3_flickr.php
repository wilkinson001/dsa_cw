<?php
  //http://www.flickr.com/services/api/response.php.html

/**
 * Class: mdp3_flickr
 * 
 * Class used to query flickr api and can make galleries for output on a page
 * 
 * http://www.mdp3.net
 */
class mdp3_flickr
{
  var $apiKey;
  var $secret;
  
  /**
   *
   * @param string $apiKey your api key
   * @param string $secret your api secret key
   * 
   * Creates new object w/ api keys
   */
  function mdp3_flickr($apiKey, $secret = "")
  {
    $this->apiKey = $apiKey;
    $this->secret = $secret;
  }
  
  /**
   *
   * @param array $params params array for query url
   * @return array an array of strings from php unserialized api response
   * 
   * Queries flickr api with url built from params array for info see flickr API
   */
  private function query($params)
  {
    $encoded_params = array();

    foreach ($params as $k => $v)
      $encoded_params[] = urlencode($k).'='.urlencode($v);

    $url = "https://api.flickr.com/services/rest/?".implode('&', $encoded_params);

    $rsp = file_get_contents($url);
    $rsp_obj = unserialize($rsp);
    return $rsp_obj;
  }
  
  /**
   *
   * @param string $username username to search
   * @return string nsid for user
   * 
   * Searches flickr by username to get the userid or nsid number
   */
  public function findByUsername($username)
  {
    $params = array(
      'api_key'   => $this->apiKey,
      'method'    => 'flickr.people.findByUsername',
      'username'  => $username,
      'format'    => 'php_serial',
      );
    
    $rsp_obj = $this->query($params);
    
    if ($rsp_obj['stat'] == 'ok')
      return $rsp_obj['user']['nsid'];
    else
      return false;
  }
  
  /**
   *
   * @param string $photo_id
   * @return array result of photoinfo query
   * 
   * queries w/ info necessary to get photo info for a photo id number and 
   * returns the array of info
   */
  function loadPhotoInfo($photo_id)
  {
    $params = array(
    'api_key'	=> $this->apiKey,
    'method'	=> 'flickr.photos.getInfo',
    'photo_id'	=> $photo_id,
    'format'	=> 'php_serial',
    );
    
    $rsp_obj = $this->query($params);

    if ($rsp_obj['stat'] == 'ok')
      return $rsp_obj;
    else
      return false;
  }
  
  /**
   *
   * @param string $photo_id
   * @param array photoInfo photo info aray returned by load photo info
   * @return string url for photo page
   * 
   * if photoInfo is false or empty, it loads photo info for photo id, if not
   * it looks in the array and gets the url for the photo page from it
   */
  function getPhotoUrl($photo_id, $photoInfo = false)
  {
    if ($photoInfo) 
      $photo = $photoInfo;
    else
      $photo = $this->loadPhotoInfo($photo_id);
    $url = $photo['photo']['urls']['url'][0]['_content'];
    return $url;
  }

  /**
   *
   * @param <string> $photo_id flickr photo id
   * @param <string> $user_id flickr user id number
   * @return <string> photo page url
   * 
   * Simple function to create the photo page url with a photo id and user id
   */
  function makePhotoPageUrl($photo_id, $user_id)
  {
    $url = "https://www.flickr.com/photos/$user_id/$photo_id";
    return $url;
  }
  
  /**
   *
   * @param string $user_id user id nsid of user
   * @param int $per_page photos per page
   * @param int $page page number
   * @param string $extras extra fields to get see flickr api
   * @return array response array of photo info
   * 
   * Gets the public photos for user_id returns response array
   */
  function getPublicPhotosForUserNoAuth($user_id, $per_page = 100, $page = 1, $extras = "")
  {
    $params = array(
        'api_key'   => $this->apiKey,
        'method'    => 'flickr.people.getPublicPhotos',
        'user_id'   => $user_id,
        'per_page'  => $per_page,
        'page'      => $page,
        'extras'    => $extras,
        'format'    => 'php_serial',
        );
    
    $rsp_obj = $this->query($params);
    //print_r($rsp_obj['photos']['photo']);
    return $rsp_obj['photos'];
  }

  /**
   *
   * @param <string> $user_id flickr nsid
   * @return <array> 
   * 
   * Returns a list of all photo sets for user_id
   */
  function getUserSetList($user_id)
  {
    $params = array(
        'api_key'   => $this->apiKey,
        'method'    => 'flickr.photosets.getList',
        'user_id'   => $user_id,
        //'per_page'  => $per_page,
        //'page'      => $page,
        'format'    => 'php_serial',
        );

    $rsp_obj = $this->query($params);

    return $rsp_obj['photosets'];
  }

  /**
   *
   * @param <string> $photoset_id flickr photoset id
   * @param <string> $per_page number of photos per page
   * @param <string> $page page number to return
   * @param <string> $media media typer to return, all, photos, or videos
   * @param <type> $extras extra info to return http://www.flickr.com/services/api/flickr.photosets.getPhotos.html
   * @return <array> array of photo ids
   * 
   * Returns a list of photos in set by page
   */
  function getPhotosInSet($photoset_id, $per_page = 500, $page = 1, $media = "all", $extras = "")
  {
    $params = array(
        'api_key'   => $this->apiKey,
        'method'    => 'flickr.photosets.getPhotos',
        'photoset_id'   => $photoset_id,
        'extras'    => $extras,
        'per_page'  => $per_page,
        'page'      => $page,
        'media'     => $media,
        'format'    => 'php_serial',
        );

    $rsp_obj = $this->query($params);

    return $rsp_obj['photoset'];
  }
  
  /**
   *
   * @param array $photoAr array of photo info
   * @param string $suffix flickr file suffix for image size to get
   * @return string url to image
   * 
   * Returns a url string to the img from an array of photo info from getPublicPhotos
   *
   * The letter suffixes are as follows:
   * s	small square 75x75
   * t	thumbnail, 100 on longest side
   * m	small, 240 on longest side
   * -	medium, 500 on longest side
   * z	medium 640, 640 on longest side
   * b	large, 1024 on longest side*
   * o	original image, either a jpg, gif or png, depending on source format
   * Before May 25th 2010 large photos only exist for very large original images.
   */
  function makePhotoImageURLfromArray($photoAr, $suffix = "")
  {
    $farmid = $photoAr['farm'];
    $serverid = $photoAr['server'];
    $photoid = $photoAr['id'];
    $secret = $photoAr['secret'];
    
    return $this->makePhotoImageURL($farmid, $serverid, $photoid, $secret, $suffix);
  }

  /**
   *
   * @param string $farmid 
   * @param string $serverid
   * @param string $photoid
   * @param string $secret
   * @param string $suffix
   * @param string $fileType
   * @return string url to photo 
   * 
   * Builds a flickr image url w/ all necessary parts
   *
   * * The letter suffixes are as follows:
   * s	small square 75x75
   * t	thumbnail, 100 on longest side
   * m	small, 240 on longest side
   * -	medium, 500 on longest side
   * z	medium 640, 640 on longest side
   * b	large, 1024 on longest side*
   * o	original image, either a jpg, gif or png, depending on source format
   */
  function makePhotoImageURL($farmid, $serverid, $photoid, $secret, $suffix = "", $fileType = "jpg")
  {
    if ($suffix != "")
      $suffix = "_" . $suffix;
    $url = "http://farm" . $farmid . ".static.flickr.com/" . $serverid . 
            "/" . $photoid . "_" . $secret . $suffix . "." . $fileType;
    return $url;
  }
}