<html>
  <head>
    <link rel="stylesheet" type="text/css" href="phpFlickrGallery.css" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Social Media</title>
	<body style="background-color:#4c4a4a;">
	<font color=#FFFFFF>
	<font face="Verdana" size="2">
  </head>
 </html>
<h1>Tweets from Haut Espoir Vineyard, Franschhoek, South Africa</h1>
<?php
 //Based on code by mikel_duke http://www.mdp3.net
  include("phpFlickrGallery.php");
  
  $username = 'mugwazere';    
  $amount_per_page = 12;

  if (isset($_GET['image']))
    $imageid = $_GET['image'];
  else $imageid = false;

  if (isset($_GET['set']))
    $setid = $_GET['set'];
  else $setid = false;
  
  
        //Based on code by James Mallison, see https://github.com/J7mbo/twitter-api-php
        ini_set('display_errors', 1);
        require_once('TwitterAPIExchange.php');
        header('Content-Type: text/html; charset="UTF-8"');
        
        /** Set access tokens here - see: https://dev.twitter.com/apps/ **/
        $settings = array(
            'oauth_access_token' => "53392926-zds2MIH5NcAWXQvPBbSjQSPahO04W1RI1otzTbHmU",
            'oauth_access_token_secret' => "ZurcV7GvTugs3HhlB34jtmL02RrV0JQgRPyfQZQtKBSq7",
            'consumer_key' => "R0p9KfATQfNVam8sjuzxbm5XS",
            'consumer_secret' => "hQZHtvVaN8hsNQBBvBFdodgG2sozSAHeY9hn5oTVrLjqZQ7oKa"
        );
        
        /** Perform a GET request and echo the response **/
        /** Note: Set the GET field BEFORE calling buildOauth(); **/
        $url = 'https://api.twitter.com/1.1/search/tweets.json';
        $getfield = '?q=&geocode=-33.917,19.120,2km';
        $requestMethod = 'GET';
        $twitter = new TwitterAPIExchange($settings);
        $data=$twitter->setGetfield($getfield)
                     ->buildOauth($url, $requestMethod)
                     ->performRequest();
        
        //Use this to look at the raw JSON
        //echo($data);
        
        // Read the JSON into a PHP object
        $phpdata = json_decode($data, true);
        
        // Debug - check the PHP object
        //var_dump($phpdata);
        
        //Loop through the status updates and print out the text of each
        foreach ($phpdata["statuses"] as $status){
        	echo("<p>" . $status["text"] . "</p>");
        }
?>

<h1>Flickr Images of wines and vineyard in South Africa</h1>
<html>
  <body>
    <? 
      if (!$imageid) showGallery($username, $amount_per_page);
      else viewImage($imageid, "b");
    ?>
	  <br>
    <label for="source"><p class="sansserif">Searchtweets:
  <input type="text" name="source" placeholder="Enter hastag" style="width: 600px; height: 25">
    </font><br />
  </body>
</html>
