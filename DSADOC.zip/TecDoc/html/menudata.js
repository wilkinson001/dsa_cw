var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Related Pages",url:"pages.html"},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"Globals",url:"globals.html",children:[
{text:"All",url:"globals.html",children:[
{text:"$",url:"globals.html#index_0x24"},
{text:"e",url:"globals.html#index_e"},
{text:"f",url:"globals.html#index_f"}]},
{text:"Functions",url:"globals_func.html"},
{text:"Variables",url:"globals_vars.html",children:[
{text:"$",url:"globals_vars.html#index_0x24"},
{text:"e",url:"globals_vars.html#index_e"},
{text:"f",url:"globals_vars.html#index_f"}]}]}]}]}
