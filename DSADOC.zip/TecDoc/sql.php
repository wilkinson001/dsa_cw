<?php



/**PHP File Returns rows of weathr/location data */
check if function exists (was getting errors from includes)
if(!function_exists('call_sql')){
	function call_sql($sql){
		/**Calls db_connection.php, connects to the database */
		include('db_connection.php');
		/**get results of query*/
		$result = mysqli_query($connection,$sql, MYSQLI_ASSOC);
		/**add results to rows of array while there are results */
		while($row=$result->fetch_assoc()){
			$rows[] = $row;
		}
		/**close results */
		$result->close();
		if(!isset($rows)){return $rows[] = "";}
		/**return results */
		return $rows;
	}
}
?>